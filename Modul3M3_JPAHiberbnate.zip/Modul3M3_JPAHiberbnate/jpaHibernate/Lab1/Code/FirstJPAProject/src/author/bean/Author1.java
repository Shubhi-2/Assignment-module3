package author.bean;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
@Entity
@Table
public class Author1 {
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int a_id;
	private String aname;
	private String amiddle;
	private String alast;
	private String aphno;
	
	
	public Author1(int a_id, String aname,String amiddle,String alast,String aphno)
	{
		super();
		this.a_id=a_id;
		this.aname=aname;
		this.amiddle=amiddle;
		this.alast=alast;
		this.aphno=aphno;
	}
		
	public Author1()
	{
		super();
	}

	public int getA_id() {
		return a_id;
	}

	public void setA_id(int a_id) {
		this.a_id = a_id;
	}

	public String getAname() {
		return aname;
	}

	public void setAname(String aname) {
		this.aname = aname;
	}

	public String getAmiddle() {
		return amiddle;
	}

	public void setAmiddle(String amiddle) {
		this.amiddle = amiddle;
	}

	public String getAlast() {
		return alast;
	}

	public void setAlast(String alast) {
		this.alast = alast;
	}

	public String getAphno() {
		return aphno;
	}

	public void setAphno(String aphno) {
		this.aphno = aphno;
	}


}
