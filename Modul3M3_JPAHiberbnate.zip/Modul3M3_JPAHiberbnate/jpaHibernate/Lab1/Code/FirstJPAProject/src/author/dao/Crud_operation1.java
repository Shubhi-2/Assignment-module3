package author.dao;



import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;



import employee.bean.Employee;
import author.bean.Author1;



public class Crud_operation1 {
	static EntityManagerFactory emfactory=Persistence.createEntityManagerFactory("FirstJPAProject");
	static EntityManager entitymanager=emfactory.createEntityManager();
	
	public static void main(String args[])
	{
		Crud_operation1 crud_op1=new Crud_operation1();
		System.out.println("Mahima Gupta");
		//Author1 a1=new Author1();
		//Author1 a3= crud_op1.getDetails(10981);
		/*Author1 a4=new Author1();
		a4.setA_id(10978);
		a4.setAname("Sheila");
		a4.setAmiddle("Kumari");
		a4.setAlast("Dixit");
		a4.setAphno("8009876543");*/
		//crud_op1.InsertIntoAuthorBean(a4);
		/*a1.setA_id(10101);
		a1.setAname("Akash");
		a1.setAmiddle("Kumar");
		a1.setAlast("Pandey");
		a1.setAphno("8900756889");
		crud_op1.InsertIntoAuthorBean(a1);
		
	
		Author1 a2=new Author1();
		a2.setA_id(10981);
		a2.setAname("Priya");
		a2.setAmiddle("Prakash");
		a2.setAlast("Singh");
		a2.setAphno("8908905649");
	
		crud_op1.InsertIntoAuthorBean(a2);*/
		
	
		//crud_op1.updateAuthor(10978,"Kratika");
 
		crud_op1.deleteAuthor(10978);
		
/*System.out.println("Author id is"+a3.getA_id());
System.out.println("Author name is"+a3.getAname());
System.out.println("Author middlename is"+a3.getAmiddle());
System.out.println("Author lastname is"+a3.getAlast());
System.out.println("Author phno is"+a3.getAphno());*/
		
	}
	

	

	private void InsertIntoAuthorBean(Author1 a1) {
		entitymanager.getTransaction().begin();
		 entitymanager.persist(a1);
		 entitymanager.getTransaction().commit();
			
		
	}
private void updateAuthor(int a_id, String aname) {
		
		entitymanager.getTransaction().begin();
		Author1 a4=entitymanager.find(Author1.class, a_id);
		a4.setAname(aname);
		entitymanager.getTransaction().commit();
		
	}
private void deleteAuthor(int aid) {
	
	entitymanager.getTransaction().begin();
	Author1 a4= entitymanager.find(Author1.class,aid);
	entitymanager.remove(a4);
	
	entitymanager.getTransaction().commit();
	
}
public Author1 getDetails(int a_id) {
	
	Author1 a=entitymanager.find(Author1.class,a_id);
	return a;
	


}
	
	


}
