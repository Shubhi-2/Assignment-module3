package com.sunsoft.SpringBootDemo.Controller;


import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.sunsoft.SpringBootDemo.Entity.ProductV1;
import com.sunsoft.SpringBootDemo.exception.InvalidProductIdException;
import com.sunsoft.SpringBootDemo.exception.InvalidProductNameException;



@RestController
@RequestMapping("/product")
public class EmployeeController {
	
	
	 @GetMapping(path="/v2/isValid", produces=MediaType.APPLICATION_JSON_VALUE)
	  public ProductV1 productV1() {
	    ProductV1 product =new ProductV1();
	    product.setId(105);
	    
	    
	    product.setName("Samsung tV");
	    return product;
	    
	    
	    
	
	 @GetMapping(value = "/product/param", params = "version=1")
	 public ProductV1 productV11() {
		 System.out.println("Mahima");
		    ProductV1 product =new ProductV1();
		    product.setId(105);
		    
		    
		    product.setName("Samsung tV");
		    return product;
		    
		    

}
	
}

