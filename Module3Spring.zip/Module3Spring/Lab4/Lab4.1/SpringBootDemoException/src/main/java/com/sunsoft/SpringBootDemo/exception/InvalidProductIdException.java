package com.sunsoft.SpringBootDemo.exception;

public class InvalidProductIdException extends Exception {
	public InvalidProductIdException(String str)
	{
		super(str);
	}

}
