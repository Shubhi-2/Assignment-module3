package com.sunsoft.SpringBootDemo.exception;

public class InvalidProductNameException extends Exception {
	public InvalidProductNameException(String str)
	{
		super(str);
	}

}
