
package com.sunsoft.Entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name="TraineeJPA1")
public class Trainee {
@Id
@GeneratedValue(strategy=GenerationType.SEQUENCE,generator="id_Sequence")
@SequenceGenerator(name="id_Sequence", sequenceName="ID_SEQ")
@Column(name="id")
private int id;


@Column(name="traineeName")
String traineeName;

@Column(name="traineeDomain")
String traineeDomain;
 
@Column(name="traineeLocation")
String traineeLocation;

public int getId() {
	return id;
}



public void setId(int id) {
	this.id = id;
}



public String getTraineeName() {
	return traineeName;
}



public void setTraineeName(String traineeName) {
	this.traineeName = traineeName;
}



public String getTraineeDomain() {
	return traineeDomain;
}



public void setTraineeDomain(String traineeDomain) {
	this.traineeDomain = traineeDomain;
}



public String getTraineeLocation() {
	return traineeLocation;
}



public void setTraineeLocation(String traineeLocation) {
	this.traineeLocation = traineeLocation;
}



public Trainee() {}



@Override
public String toString() {
	return "Trainee [id=" + id + ", Trainee name ="+ traineeName+", TraineeDomain="+ traineeDomain + ", TraineeLocation="+traineeLocation+"]";
	
}
 
 

	
}