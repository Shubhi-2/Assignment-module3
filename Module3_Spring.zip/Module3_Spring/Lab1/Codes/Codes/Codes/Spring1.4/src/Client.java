import java.util.Scanner;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
public class Client {

	public static void main(String[] args) {
				// TODO Auto-generated method stub
				
            ApplicationContext context=new ClassPathXmlApplicationContext("Bean.xml");
		Employee obj=(Employee) context.getBean("hello");
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the Employee id:");
		int id=sc.nextInt();
		if(id==obj.getEmp_id()){
			


						
						System.out.println("printing details of employee");

						System.out.println("employee id:"+obj.getEmp_id());
						System.out.println("employee name:"+obj.getEmp_name());
						System.out.println("employee salary:"+obj.getSal());
						
							


				}
		else
		{
			System.out.println("Inavlid Employee id:Please enter correct Emp_Id");
		}

		}

	}


