import java.util.ArrayList;
	import java.util.Iterator;
	import java.util.List;
public class SBU {

	
	
		private String sbuCode;
		private String sbuName;
		private String sbuHead;
		public static List<Employee> empList=new ArrayList<Employee>();
		public String getSbuCode() {
			return sbuCode;
		}
		public void setSbuCode(String sbuCode) {
			this.sbuCode = sbuCode;
		}
		public String getSbuName() {
			return sbuName;
		}
		public void setSbuName(String sbuName) {
			this.sbuName = sbuName;
		}
		public String getSbuHead() {
			return sbuHead;
		}
		public void setSbuHead(String sbuHead) {
			this.sbuHead = sbuHead;
		}
		public List<Employee> getEmpList() {
			return empList;
		}
	public void setEmpList(Employee emp){
		this.empList.add(emp);
	}
		public void displayInfo()
		{
			System.out.println("Display employeeBu info:");
			Iterator it= empList.iterator();
			while(it.hasNext()) {
				Employee s=(Employee)it.next();
				
				
				System.out.println("          ");
				System.out.println("[Employee:"+ "Employee Id  is:"+s.getEmpId()+ "Employee Name:"+s.getEmpName()+"Employee Salary:"+s.getSal()+"]");
				
		
			
		}
		

	}
	}

